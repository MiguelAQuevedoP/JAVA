package modelo;

public enum eA�osExperiencia {
   sinExperiencia, DosA�os,CincoA�os,DiezA�os;
}
