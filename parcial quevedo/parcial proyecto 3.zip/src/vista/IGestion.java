package vista;

public interface IGestion {
	//CONSTANTES
	//METODOS
	void iniciarComponentes();
	void limpiarComponentes();
}
