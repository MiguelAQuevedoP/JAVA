package prueba;

import vista.JFramePrincipal;

public class clsPrincipal {

	public static void main(String[] args) {
	JFramePrincipal vtn = new JFramePrincipal ();
	vtn.setVisible(true);
	}

}
