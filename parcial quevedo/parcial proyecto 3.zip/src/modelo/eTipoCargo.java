package modelo;

public enum eTipoCargo {
   auxiliar, coordinador, cajero, jefe;
}
